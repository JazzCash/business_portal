<?php

namespace Drupal\jazz_complaint\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Class SubmitComplaintController.
 */
class SubmitComplaintController extends ControllerBase
{

  /**
   * Submit_complaint.
   *
   * @return string
   *   Return Hello string.
   */
  public function submit_complaint()
  {
    $values = array('type' => 'jazz_complaint');

    $node = \Drupal::entityTypeManager()
      ->getStorage('node')
      ->create($values);

    $formObj = \Drupal::entityTypeManager()
      ->getFormObject('node', 'default')
      ->setEntity($node);



    $form  = \Drupal::formBuilder()->getForm($formObj);
    //add template 
    array_unshift($form['#theme'], "submit_complaint_form");
    $form['actions']['submit']['#submit'][] = "nodeSubmitRedirectToComplaint";

    return $form;
  }
  /**
   * View_complaint.
   *
   * @return string
   *   Return Hello string.
   */
  public function view_complaint($node)
  {
    $ticket = $node->field_complaint_ticket->value;
    $answer = $node->field_complaint_answer->getValue();

    return [
      '#theme' => 'jazz_complaint_submit',
      '#data' => [
        'ticket' => $ticket,
        'answer' => $answer
      ]
    ];
  }
}
